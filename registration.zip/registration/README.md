"# inventory" 
